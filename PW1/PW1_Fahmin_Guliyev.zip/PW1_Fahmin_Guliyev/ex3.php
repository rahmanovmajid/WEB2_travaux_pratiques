<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php  

$n=4;
$square=pow($n,2);
$cube=pow($n,3);

echo "the square of $n is $square \n";
echo "the cube of $n is $cube \n";

?>

</body>
