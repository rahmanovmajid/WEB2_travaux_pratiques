<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php    

$start_value=2;
$end_value=12;
for($i=$start_value; $i<=$end_value; $i++) {
	echo "$i \n";
}

while($start_value<=$end_value) {
	echo "$start_value \n";
	$start_value++;

}


?>

</body>
