<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php  

$R=4;
$diameter=$R*2;
$perimeter_circle=2*M_PI*$R;
$area_circle=M_PI*pow($R,2);

echo "the diameter of circle with radius: $R is $diameter \n";
echo "the area of circle with radius: $R is $area_circle \n";
echo "the perimeter of circle with Radius: $R is $perimeter_circle \n\n";

?>

</body>
