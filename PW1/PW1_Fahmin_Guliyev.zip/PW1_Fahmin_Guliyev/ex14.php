<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php    

$number=140;

if($number>100) {
	echo "the given number $number is larger than 100 \n";

}
else if ($number<100) {
	echo "the given number $number is smaller than 100 \n";
}
else {
	echo "the given number $number is equal to 100";
}



?>

</body>
