<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php  



$days=5;
$hours=$days*24;
$minutes=$hours*60;
$seconds=$minutes*60;

echo " $days days is $hours hours or $minutes minutes, or $seconds seconds \n\n";


?>

</body>
