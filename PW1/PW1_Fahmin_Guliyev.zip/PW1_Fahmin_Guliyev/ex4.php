<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php  

$L=5;
$I=6;

$area=$L*$I;
$perimeter=($L+$I)*2;

echo "the area of rectangle with Length: $L and Width: $I is $area \n";
echo "the perimeter of rectangle with Length: $L and Width: $I is $perimeter \n\n";	

?>

</body>
