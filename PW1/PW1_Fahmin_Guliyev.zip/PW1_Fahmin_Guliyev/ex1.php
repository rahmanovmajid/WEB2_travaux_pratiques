<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php

$var1=5;
$var2=2;

$sum=$var1+$var2;
$sub=$var1-$var2;
$mult=$var1*$var2;
$div=$var1/$var2;


echo "sum is $sum \n";
echo "subtraction is $sub \n";
echo "multiplication is $mult \n";
echo "division is $div \n";

?>

</body>
