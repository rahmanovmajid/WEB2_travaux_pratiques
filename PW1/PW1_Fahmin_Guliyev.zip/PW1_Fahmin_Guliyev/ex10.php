<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php    

$start_value=4;
$end_value=12;

echo "the sequence of even numbers from $start_value to $end_value \n";
while($start_value<=$end_value) {
	echo "$start_value \n";
	$start_value+=2;

}


?>

</body>
