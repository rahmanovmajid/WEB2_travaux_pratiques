<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php  


$var1=5;
$var2=2; 
$modulo=$var1%$var2;                                                                                                                        echo "the rest of the division of $var1 on $var2 is $modulo \n\n";

?>

</body>
