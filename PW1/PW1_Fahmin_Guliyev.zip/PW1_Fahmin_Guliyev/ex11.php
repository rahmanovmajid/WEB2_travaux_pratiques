<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>nese </title>
</head>
<body>

<?php    


$given_number=4;


echo " multiplication table for $given_number\n";

for($i=1;$i<=10;$i++) {
	$ans=$given_number*$i;
	 echo " $given_number * $i = $ans \n";
}


?>

</body>
