<?php
//1 line comment

/*
comment on multiple lines
php statements end with a semicolon ;
*/
$variable="value";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>How to PHP</title>
</head>
<body>
<?php
echo "<h1>How to PHP</h1>";

?>
<element attribute="<?php  echo $variable;  ?>">

</element>	

</body>
</html>
<?php

?>

